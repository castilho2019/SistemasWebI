function openMenu(){
    let menu = document.getElementById("hamburguer-menu-open");
    let icon = document.querySelector("#hamburguer-icon");
    
    if (menu.style.display === "flex") {
        menu.style.display = "none"
        icon.innerHTML = "menu"
    } else {
        menu.style.display = "flex"
        icon.innerHTML = "close"
    }
}

const products = [
    {
        id: 1,
        title: "Adesivo tribal",
        price: 200,
        img: "resources/images/adesivo tribal.webp"
    },
    {
        id: 1,
        title: "BMW 2550 1.0",
        price: 900000,
        img: "resources/images/bmw.jpg"
    },
    {
        id: 3,
        title: "BMW 1550 4.0 TURBO",
        price: 900000,
        img: "resources/images/carro.webp"
    },
    {
        id: 4,
        title: "Carro 2",
        price: 900000,
        img: "resources/images/carro 2.webp"
    }
    ,{
        id: 5,
        title: "Chevrolet",
        price: 900000,
        img: "resources/images/carro 3.webp"
    },
    {
        id: 6,
        title: "LG 1243",
        price: 900000,
        img: "resources/images/celular.jpg"
    },
    {
        id: 7,
        title: "Esfregão",
        price: 900000,
        img: "resources/images/esfregao.jpg"
    },
    {
        id: 8,
        title: "HB20",
        price: 250000,
        img: "resources/images/HB20.jpg"
    },
    {
        id: 9,
        title: "Lenoxx dual sim",
        price: 1450,
        img: "resources/images/lenoxx.png"
    },
    {
        id: 10,
        title: "LIGHTYEAR 2",
        price: 790000,
        img: "resources/images/lightyear.jpg"
    },
    {
        id: 11,
        title: "Moto G30",
        price: 2300,
        img: "resources/images/Moto G30.webp"
    },
    {
        id: 12,
        title: "Multilaser Vita",
        price: 800,
        img: "resources/images/multilaser vita.webp"
    },
    {
        id: 13,
        title: "Multilaser",
        price: 1380,
        img: "resources/images/multilaser.webp"
    },
    {
        id: 14,
        title: "Poco x3",
        price: 2100,
        img: "resources/images/poco x3.webp"
    },
    {
        id: 15,
        title: "Redmi 9a",
        price: 2100,
        img: "resources/images/redmi 9a.webp"
    },
    {
        id: 16,
        title: "Suporte para Iphone",
        price: 360,
        img: "resources/images/suporte iphone.jpg"
    },
    {
        id: 18,
        title: "tiggo 8 min",
        price: 350000,
        img: "resources/images/tiggo 8 min.jpg"
    },
    
]

document.addEventListener("DOMContentLoaded", function (){
    render(products)
});

function render(products){
    let container = document.getElementById("product-list")

    products.forEach(product => {

        const li = document.createElement('li')

        const div = document.createElement('div');
        div.className = 'product-item';
        div.id = 'products-item';
    
        const img = document.createElement('img');
        img.id = 'product-image';
        img.src = product.img;
    
        const h1 = document.createElement('h1');
        h1.className = 'products-text';
        h1.id = 'product-title';
        h1.textContent = product.title;
    
        const h2 = document.createElement('h2');
        h2.className = 'products-text';
        h2.id = 'product-price'
        h2.textContent = `R$ ${product.price.toFixed(2)}`;

        div.appendChild(img)
        div.appendChild(h1)
        div.appendChild(h2)
        li.appendChild(div)
        container.appendChild(li)
    })
}


